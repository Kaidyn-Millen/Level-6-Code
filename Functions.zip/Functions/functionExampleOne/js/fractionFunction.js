var fractionPromptNumOne = prompt("Please Input a number to turn into a fraction");
var fractionPromptNumTwo = prompt("Please input a second number to turn into a fraction");

var fractionDivideNumOne = prompt("Please Input a number to turn into the dividing fraction");
var fractionDivideNumTwo = prompt("Please input a secondary number to turn into a dividing fraction");

var fractionOne = fractionPromptNumOne / fractionDivideNumOne;
var fractionTwo = fractionDivideNumTwo / fractionDivideNumTwo; 

function obtainBiggestFraction()
{
    if(fractionOne > fractionTwo)
    {
        document.write("Fraction One: " + fractionOne);
    }

    else if(fractionOne < fractionTwo)
    {
        document.write("Fraction Two : " + fractionTwo);
    }

    else 
    {
        document.write("They are equal! ");
    }
} //This marks the end of the function

obtainBiggestFraction();