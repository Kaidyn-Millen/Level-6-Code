 var results;
 
 function obtainBiggestFraction(fractionOne, fractionTwo)
{

   

    if(fractionOne > fractionTwo)
    {
        results = ("first fraction" + fractionOne)
    }

    else if(fractionOne < fractionTwo)
    {
       results = ("first fraction" +  fractionTwo);
    }

    else 
    {
        results = ("equal");
    }
    
    return results;

} //This marks the end of the function


function displayResult(newResult){
    document.getElementById("results").innerHTML = "Fraction " + newResult[0] + " with a value of ";

}

var fractionOne = 4/5;
var fractionTwo = 6/9;

var fractionResults = findBiggestFraction(fractionOne, fractionTwo);

document.write("Hello this is fraction " + fractionResults);

displayResult(fractionResult);
