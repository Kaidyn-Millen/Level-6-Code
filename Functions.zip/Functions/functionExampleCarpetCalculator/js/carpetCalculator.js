

function carpetCalculator()
{


roomLength = prompt("Please input the length of the room");
roomWidth = prompt("Please input the width of the room");

roomArea = roomLength * roomWidth;





if(roomArea > 100)
{
    acrylicCarpet();
}

else if(roomArea <= 100)
{
    nylonCarpet();
}

}


function acrylicCarpet()
{

    document.write("With the length of " + roomLength + " and " + roomWidth + " making the area " + roomArea + ",  which means  Acrycllic Carpet might suit you");
}


function nylonCarpet()
{
    document.write("With the lenght of " + roomLength + " and " + roomWidth + " making the area " + roomArea + ",  which means Nylon Carpet might suit you");
}



carpetCalculator();