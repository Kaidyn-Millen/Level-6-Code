
function yearChoice()
{
var whatYear = prompt("Decide which of the two years (2017 or 1999) you want to see calculated for Freddos from the minimum wage")

if(whatYear == 1999)
{
	ninetyNine();
}

else if(whatYear == 2017)
{
	twentySeventeen();
}

}

function ninetyNine()
{
	var minumWage = prompt("Input your minimum wage");

	var freddo = 0.05;

	var amountOfFreddos = minumWage / freddo;

	//document.write("The amount of Freddos you are able to get based on "+minumWage+" an hour is: "+amountOfFreddos);
	document.write("Minimum Wage £"+minumWage+"/hr <br> Cost of a Freddo: 5p <br> Freddos per hour: "+amountOfFreddos + '<img src="img/Freddoaus.jpg" alt="Freddo5P" width="100" height="135">')

}


function twentySeventeen()
{
	var minumWage = prompt("Input your minimum wage");

	var freddo = 0.25;

	var amountOfFreddos = minumWage / freddo;

	document.write("Minimum Wage £"+minumWage+"/hr <br> Cost of a Freddo: 25p <br> Freddos per hour: "+amountOfFreddos + '<img src="img/freddoTwentyFive.jpg" alt="Freddo5P" width="100" height="135">')
	//document.write("The amount of Freddos you are able to get based on "+minumWage+" an hour is: "+amountOfFreddos);

}

yearChoice();
