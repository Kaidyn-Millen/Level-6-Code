//Kaidyn Millen, 16/10/2020,  FreddoV2

var minumWage1999 =parseFloat(prompt("Input your minimum wage for 1999"));
var minumWage2017 = parseFloat(prompt("Input your minimum wage for 2017"));
var freddo5p = parseFloat(prompt("Input price of 1999 Freddo:"));
var freddo25p = parseFloat(prompt("Input price of 2017 Freddo:"));
var freddo5pDevision = minumWage1999 / freddo5p;
var freddo25pDevision = minumWage2017 / freddo25p;

	
	document.write("1999 Minimum Wage £"+minumWage1999+"/hr <br> Cost of a Freddo: £"+freddo5p+"p <br> Freddos per hour: "+freddo5pDevision+"<br>"+"<br> 2017 Minimum Wage £"+minumWage2017+"/hr <br> Cost of a Freddo: £"+freddo25p+"p <br> Freddos per hour: "+freddo25pDevision)

