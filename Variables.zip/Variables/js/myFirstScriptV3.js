var surname;
var forename;

surname = "Millen";
forename = "Kaidyn";

alert("Weclome " + forename + " " + surname);

surname = "KM";

alert(surname);

var age = 20;
var mood;
var height = 74.4;
var minHeightRequired = 70;

alert("Height = minHeightRequired is " + (height == minHeightRequired));

var favouriteMusic = [ "Gorillaz ", "Wax Fan ", "Freak Kitches ", "Dethklok " ];

alert(favouriteMusic);

var firstName = prompt("Please enter your first name");
var secondName = prompt("Please enter your  surname");

alert("Welcome " + name + " " + secondName + "! Hope you are getting the hang of coding with Javascript?");
