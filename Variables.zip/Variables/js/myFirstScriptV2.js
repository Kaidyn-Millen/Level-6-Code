var surname;
var forename;

surname = "Mary"
forename = "Jane"

alert("Weclome " + surname + " " + forename);

surname = "MJ";

alert(surname);

var age = 20;
var mood;
var height = 74.4;
var minHeightRequired = 70;

alert("Height = minHeightRequired is " +(height>= minHeightRequired));
