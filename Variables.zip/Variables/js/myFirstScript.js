var surname;
var forename;

surname = "Mary"
forename = "Jane"

alert("Weclome " + surname + " " + forename);