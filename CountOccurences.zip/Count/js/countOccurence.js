arrayNames = ['Andrew','Lili','Damon','Stephen','Brodie','Piotr','Drew','Bianca','Nathan','Andrew','Damon','Brodie','Andrew'];

arrayLength = arrayNames.length;

var namePrompt = prompt("Please input a name");

var namesOccured = 0;
var namesFromArray = false

for(count = 0; count < arrayLength; count++)
{
    if(arrayNames[count] == namePrompt) {
        namesFromArray = true ;
        namesOccured++;
        var namesFinalOccurance = namesOccured;

       document.write(arrayNames[count] + " is in position " + count + "</br>");
        
    }

    else if(namesFromArray == false){
    document.write("user is not on this list");
}

}

document.write(namePrompt + " appears " + namesFinalOccurance + " times in the array "+"<br>");




















