 
 
var baseSalary = parseInt(prompt("Input the Basic Salary"));
var bonusCash = parseInt(prompt("Input the Bonus"));
var taxFreeAllowance = parseInt(prompt("Input the Tax Free Allowance"));
var totalSalary = baseSalary + bonusCash;
var taxableIncome = totalSalary - taxFreeAllowance;
var netWeeklyTax = taxableIncome / 52;
var percentialCalc = taxableIncome / 100;
var twentyFivePerCent = percentialCalc * 0.25;
var sixtyFivePerCent = percentialCalc * 0.65;

        
            

        if(taxableIncome <= 24000)
            {
                document.write("The Net Income after Tax is: " + twentyFivePerCent + "</br> The net weekly pay is " + netWeeklyTax); 
            }

            else if(taxableIncome >= 44000)
                 {
                     document.write("Your Net Income after Tax is: " + sixtyFivePerCent + "</br> The net weekly pay is: " + netWeeklyTax);
                 }