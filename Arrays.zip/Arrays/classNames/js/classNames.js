
	var count = prompt("Please input the number");
	var classMates = ["Aidan", "David", "Rowan", "Vaida", "Daniel", "Ronnie"];
	

	for(count=0; count<classMates.length; count++)
	{
		document.write("Good Afternoon "+classMates[count] + "<br>");
	}

