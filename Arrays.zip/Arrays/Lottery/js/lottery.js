
var lotteryNum = new Array();
lotteryNum = [];
lotteryNum.sort()



for(var count=0; count < 6 ; count++)
	{   
        randomNum = Math.floor(Math.random() * 100);

        lotteryNum.push(randomNum);

		document.write("This is " + lotteryNum[count] + "<br>");
	}


