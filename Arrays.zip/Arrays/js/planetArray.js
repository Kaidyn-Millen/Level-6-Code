planetInSystem = ["Mercury ", "Venus ", "Earth ", "Mars ", "Jupiter ", "Saturn ", "Uranus ", "Neptune "];
   

planetDistanceSystem =  ["46.345 million km ", "107.48 million km ", "148.54 million km ", "215.59 million km ", "766.01 million km ", "1.4927 billion km ", "2.9589 billion km ", "4.4762 billion km"];

    
count = 0;

for(count =0; count < planetInSystem.length; count++)
{
    document.write(" " + planetInSystem[count] +" is " + planetDistanceSystem[count] + " away from the sun"+"<br>");
}
