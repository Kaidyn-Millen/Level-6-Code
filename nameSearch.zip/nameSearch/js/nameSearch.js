var nameArray = ["Daniel", "Aiden", "Kyle", "Leah", "Stefan", "Rowan", "David", "Jerry", "Thomas", "Maks", "Liam", "Haiden", "Ryder", "Jasiu", "Ethan"];
var arrayLength = nameArray.length;
var nameChoice = prompt("Please enter a name to search for: ");
var addressName;
var addressFound = false;

for(var count = 0; count < arrayLength; count++)
{
    if(nameChoice == nameArray[count])
    {
        addressName = count;
        addressFound = true;
        
    }
    
   
}

if(addressFound == true)
{
    document.write("The Name "+nameChoice+" is located at address "+ addressName);

}

else if(addressFound == false)
{
    document.write("The Name " +nameChoice+ " is not on the list");
}